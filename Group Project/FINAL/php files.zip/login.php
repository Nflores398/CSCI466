<?php
	$username = 'z1816398';
	$password = '1998Oct05';
?>
